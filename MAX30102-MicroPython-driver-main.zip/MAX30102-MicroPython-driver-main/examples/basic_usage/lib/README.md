# Note

To manually install the library, copy the files `max30102/circular_buffer.py`,  `max30102/max30102.py` and past them here.

Then, load the content of `example` directory into the board.
